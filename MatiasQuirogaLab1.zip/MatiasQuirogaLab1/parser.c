#include <stdlib.h>
#include <stdio.h>
#include "parser.h"
#include "LinkedList.h"
#include "computer.h"

FILE* openFILE (char* filename)
{
    FILE* ret = NULL;
    if (filename!=NULL)
    {
        ret = fopen(filename,"r");
    }
    return ret;
}
FILE* openFILEwrite(char* filename)
{
    FILE* ret = NULL;
    if (filename!=NULL)
    {
        ret = fopen(filename,"w");
    }
    return ret;
}
int parser_FromText(FILE* pFile , void* this)
{
    int retVal = 0;
    if (pFile!=NULL&&this!=NULL)
    {
        this = (LinkedList*)this;
        char buffer [6][128];
        fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",buffer[0],buffer[1],buffer[2],buffer[3]);
        while (!feof(pFile))
        {
            eComputer* newComputer;
            fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",buffer[0],buffer[1],buffer[2],buffer[3]);// "%[^,],%[^,],%[^,],%[^\n]\n"
            newComputer = new_text(buffer[0],buffer[1],buffer[2],buffer[3]);
            if (newComputer!=NULL)
            {
                ll_add(this,newComputer);
                retVal++;
            }
        }
    }
    return retVal;
}

int parser_ListToText (FILE* pFile, void* this)
{
    int retVal = 0;
    if (pFile!=NULL&&this!=NULL)
    {
        this = (LinkedList*)this;
        char name[128] ;
        char aux[50];
        int id , precio, idTipo;
        eComputer* auxmov;
        int i;
        fprintf(pFile,"id,descripcion,precio,tipo\n");
        for (i=0;i<ll_len(this);i++)
        {
            auxmov = (eComputer*)ll_get(this,i);
            if (auxmov!=NULL)
            {
                get_id(auxmov,&id);
                get_name(auxmov,name);
                get_precio(auxmov,&precio);
                get_idTipo(auxmov,&idTipo);
                if(idTipo == 1)
                {
                    strcpy(aux,"DESKTOP");
                }
                fprintf(pFile,"%d,%s,%d,%s\n",id,name,idTipo,idTipo);
            }
        }
        retVal = 0;
    }
    return retVal;
}


int archivo_cargar(char* nombreArchivo, LinkedList* nombreLista)
{
    FILE* pArchivo;
    eComputer* pAuxEstructura;

    int retorno=-1;
    int flag = 0;

    //Variables auxiliares de estructura
    char auxId[60];
    char auxDescripcion[100];
    char auxPrecio[60];
    char auxIdInt[100];

    int cantidadDatos=0;

    if(nombreLista!=NULL)
    {
        pArchivo=fopen(nombreArchivo,"r");
        if(pArchivo!=NULL)
        {
            do
            {
                cantidadDatos=fscanf(pArchivo,"%[^,],%[^,],%[^,],%[^\n]\n",auxId, auxDescripcion,
                                     auxPrecio, auxIdInt);

                if(cantidadDatos==4 && flag==0)
                {
                    flag=1;
                }
                else
                {
                    if(cantidadDatos==4 && flag==1)///Compruebo que se haya copiado toda la linea
                    {
                        pAuxEstructura= eComputer_new();

                        pAuxEstructura->id = atoi(auxId);
                        pAuxEstructura->id = atoi(auxPrecio);
                        pAuxEstructura->id = atoi(auxIdInt);
                        strcpy(pAuxEstructura->descripcion,auxDescripcion);


                        ll_add(nombreLista, pAuxEstructura);
                    }

                }


            }while(!feof(pArchivo));//Sigue iterando hasta el final del archivo

            fclose(pArchivo);

            retorno=1;//Cargo los datos
        }
        else
        {
            printf("No se pudo abrir el archivo.\n");
            retorno=0;//No se pudo abrir
        }
    }

    return retorno;

}

